const express = require("express");
const app = express();
const axios = require("axios");
const instance = axios.create();
instance.defaults.timeout = 5000;
instance.defaults.proxy = false;

//RUN THIS CODE on TERMINAL
//npm config set strict-ssl false
//export NODE_TLS_REJECT_UNAUTHORIZED=0
//--------------------------------------------APPLICATION HEADER CONFIG--------------------------------------------//
app.all("/*", function (req, res, next) {
    //CORS CONFIG
    res.header("Access-Control-Allow-Origin", "*");
    //res.header("Access-Control-Allow-Origin", "http://10.20.187.122:3001"); // restrict it to the required domain
    res.header("Access-Control-Allow-Methods", "GET,POST,OPTIONS");
    //SET CUSTOM HEADER CORS
    res.header("Access-Control-Allow-Headers", "Content-type,Accept");
    if (req.method == "OPTIONS") {
        res.status(200).end();
    } else {
        next();
    }
});
//--------------------------------------------APPLICATION HEADER CONFIG--------------------------------------------//

//--------------------------------------------PORT--------------------------------------------//
const PORT = process.env.PORT || 4001;
//--------------------------------------------PORT--------------------------------------------//

//--------------------------------------------EVENT API--------------------------------------------//
app.get("/events", (req, res) => {
    const fs = require("fs");
    let localData = fs.readFileSync("data.json");
    let events = JSON.parse(localData);
    res.json(events)
});
//--------------------------------------------EVENT API--------------------------------------------//


//--------------------------------------------EXTERNAL HTTP API--------------------------------------------//
app.get("/ExternalHttpApi", (req, res, next) => {
    console.log("'/test' call");
    axios.get('https://dummyjson.com/products/1')
        .then(response => res.json(response.data))
        .catch(err => console.log(err))
});
//--------------------------------------------EXTERNAL HTTP API--------------------------------------------//


//--------------------------------------------NODE STATUS AND LISTEN--------------------------------------------//
app.get("/status", (req, res) => {
    const status = {
        Status: "Running",
    };
    res.send(status);
});

app.listen(PORT, () => {
    console.log("Server Listening on PORT:", PORT);
});
//--------------------------------------------NODE STATUS AND LISTEN--------------------------------------------//

