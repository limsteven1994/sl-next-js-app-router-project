import React from 'react'
import Link from "next/link";
import EventCard from "@/components/card/card";

const EventLists = (props: any) => {
  const { eventList } = props;
  return (
    <div>
        {eventList.map((item: any,key:number) => {
        return (
            <Link href={`/events/${item.id}`} key={key}>
                <EventCard data={item} />
            </Link>
        );
    })}</div>
  )
}

export default EventLists