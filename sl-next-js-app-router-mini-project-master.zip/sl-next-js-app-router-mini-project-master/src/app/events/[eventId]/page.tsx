//##EVENTS DETAILS PAGE
import Stack from "@mui/material/Stack";
import Box from "@mui/material/Box";
import Avatar from "@mui/material/Avatar";
import { getEventById } from "@/app/api/api";
import Typography from "@mui/material/Typography";
import DateRangeIcon from "@mui/icons-material/DateRange";
import LocationOnIcon from "@mui/icons-material/LocationOn";
import Grid from "@mui/material/Grid";
import Link from "next/link";
import { Button } from "@mui/material";
export default async function Page({
    params,
}: {
    params: { eventId: string };
}) {
    const GetEventById = await getEventById(params.eventId);
    return (
        // <Box sx={{ flexGrow: 1, overflow: 'hidden', px: 3 }}>
        //     <Grid container spacing={2}>
        //         <Grid item
        //             justifyContent="center"
        //             alignItems="center"
        //         >
        //             <Avatar
        //                 alt={filteredEvents?.image}
        //                 src={`/${filteredEvents?.image}`}
        //                 sx={{ width: 300, height: 300 }}
        //             />
        //         </Grid>
        //         <Grid item
        //         >
        //             <Grid container wrap="nowrap">
        //             <Grid item xs>
        //                         <Typography variant="h4" component="div">
        //                             {filteredEvents?.title}
        //                         </Typography>
        //                         <Typography noWrap>
        //                             {filteredEvents?.description}
        //                         </Typography>
        //                     </Grid>
        //             </Grid>
        //         </Grid>
        //     </Grid>
        // </Box>
        <Box sx={{ flexGrow: 1, overflow: "hidden", px: 3 }}>
            <Grid container wrap="nowrap" spacing={2}>
                <Grid item>
                    <Avatar
                        alt={GetEventById?.image}
                        src={`/${GetEventById?.image}`}
                        sx={{ width: 300, height: 300 }}
                    />
                </Grid>
                <Grid item xs>
                    <Grid
                        container
                        direction="row"
                        justifyContent="space-between"
                        alignItems="flex-start"
                    >
                        <Grid item>
                        <Typography variant="h4" component="div">
                                {GetEventById?.title}
                            </Typography>
                        </Grid>
                        <Grid item>
                        <Link href="/events">
                                <Button variant="text" style={{ width: 280 }}>
                                    Back
                                </Button>
                            </Link>
                        </Grid>
                    </Grid>
                    <Typography>{GetEventById?.description}</Typography>
                    <Stack direction="row" spacing={4}>
                        <div>
                            <DateRangeIcon />
                        </div>
                        <div>{GetEventById?.date}</div>
                    </Stack>
                    <Stack direction="row" spacing={4}>
                        <div>
                            <LocationOnIcon />
                        </div>
                        <div>{GetEventById?.location}</div>
                    </Stack>
                </Grid>
            </Grid>
        </Box>
    );
}
