"use client";
import * as React from "react";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select, { SelectChangeEvent } from "@mui/material/Select";
import Grid from "@mui/material/Grid";
import { Button } from "@mui/material";
import { years, months } from "../constant/constant-filter";
export default function FilterEvents(props: any) {
    // const yearInputRef = React.useRef();
    // const monthInputRef = React.useRef();
    // const selectedYear = yearInputRef.current.value;
    // const selectedMonth = monthInputRef.current.value;

    const [month, setMonth] = React.useState<string>("");
    const [year, setYear] = React.useState<string>("");

    const handleChangeMonth = (event: SelectChangeEvent) => {
        setMonth(event.target.value);
    };
    const handleChangeYear = (event: SelectChangeEvent) => {
        setYear(event.target.value);
    };

    const handleSubmit = (event: React.SyntheticEvent) => {
        event.preventDefault();
        //alert("Form Submitted");
        props.onFilter(year, month);
    };

    return (
        <form onSubmit={handleSubmit}>
            <Grid
                container
                direction="row"
                justifyContent="center"
                alignItems="center"
            >
                <Grid item>
                    <FormControl sx={{ m: 1, minWidth: 120 }} size="small">
                        <InputLabel id="demo-select-small-label">
                            Month
                        </InputLabel>
                        <Select
                            labelId="demo-select-small-label"
                            id="demo-select-small"
                            value={month}
                            label="Month"
                            onChange={handleChangeMonth}
                        >
                            {months.map((item: any, key: number) => {
                                return (
                                    <MenuItem key={key} value={item.value}>
                                        {item.month}
                                    </MenuItem>
                                );
                            })}
                        </Select>
                    </FormControl>
                </Grid>
                <Grid item>
                    <FormControl sx={{ m: 1, minWidth: 120 }} size="small">
                        <InputLabel id="demo-select-small-label">
                            Year
                        </InputLabel>
                        <Select
                            labelId="demo-select-small-label"
                            id="demo-select-small"
                            value={year}
                            label="Year"
                            onChange={handleChangeYear}
                        >
                            {years.map((item: any, key: number) => {
                                return (
                                    <MenuItem key={key} value={item.value}>
                                        {item.year}
                                    </MenuItem>
                                );
                            })}
                        </Select>
                    </FormControl>
                </Grid>
                <Button type="submit" variant="contained">
                    Find Events
                </Button>
            </Grid>
        </form>
    );
}
