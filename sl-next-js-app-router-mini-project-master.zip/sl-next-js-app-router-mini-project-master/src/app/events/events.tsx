"use client";
import { useEffect, useState } from "react";
import Grid from "@mui/material/Grid";
import { Box } from "@mui/material";
import { getAllEvents, getFilteredEvents } from "../api/api";
import FilterEvents from "./filterEvents";
import EventLists from "./eventLists";
import EmptyEvents from "@/components/emptyFilter/emptyEvents";
export default function Events() {
    const [filteredEvents, setFilteredEvents] = useState<Object>([]);
    //const [selectedDate, setSelectedDate] = useState({ year: 0, month: 0 });
    const handleFilterEvents = (year: number, month: number) => {
        if (year === 0 && month === 0) {
            handleAllEvents();
        } else {
            getFilteredEvents({ year: year, month: month })
                .then((data) => {
                    console.log("FILTERED DATA === ", data);
                    setFilteredEvents(data);
                })
                .catch(() => {
                    console.log("Error occured when fetching filter events");
                });
        }
        //setSelectedDate({ year: year, month: month });
    };
    const handleAllEvents = () => {
        getAllEvents()
            .then((allEvents) => {
                //console.log("ALL DATA === ", allEvents);
                setFilteredEvents(allEvents);
            })
            .catch((error) => {
                console.log(error);
            });
    };

    useEffect(() => {
        handleFilterEvents(0, 0);
    }, []);
    return (

        <Box sx={{ p: 1 }}>
            {/* TEST {JSON.stringify(GetFilteredEvents,null,2)} */}
            <Grid
                container
                direction="column"
                justifyContent="center"
                alignItems="center"
                style={{ width: "100%" }}
            >
                <Grid item>
                    <FilterEvents onFilter={handleFilterEvents} />
                </Grid>
                <Grid item style={{ minWidth: 967 }}>
                    <EventLists eventList={filteredEvents} />
                    {Object.keys(filteredEvents).length == 0 && <EmptyEvents />}
                </Grid>
            </Grid>
        </Box>
    );
}
