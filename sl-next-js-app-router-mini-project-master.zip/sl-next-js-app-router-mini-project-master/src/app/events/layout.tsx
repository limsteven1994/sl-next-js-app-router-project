import DrawerAppBar from "@/components/navigation/navigation";

export default function DashboardLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    return (
        <section>
            <DrawerAppBar />
            {children}
        </section>
    );
}
