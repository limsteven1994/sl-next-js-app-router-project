//##ALL EVENTS
import Events from "./events";
export default function Page() {
    // const allEvents = await getAllEvents();
    // const handleFilterEvents = (year:number,month:number) => {
    //     console.log("get year and months", year, month)
    //     selectedYear = year;
    //     selectedMonth = month;
    // }
    // const GetFilteredEvents = await getFilteredEvents({year:selectedYear,month:selectedMonth});
    //return (
        // <Box sx={{ p: 2 }}>
        //     {/* TEST {JSON.stringify(GetFilteredEvents,null,2)} */}
        //     <Grid
        //         container
        //         direction="column"
        //         justifyContent="center"
        //         alignItems="center"
        //         spacing={1}
        //     >
        //         <Grid item>
        //             <Events />
        //             {/* <EventLists item = {allEvents}/> */}
        //         </Grid>
        //     </Grid>
        // </Box>
        //<div><Events/></div>
    //);
    return <Events/>;
}
