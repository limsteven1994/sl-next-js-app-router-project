import Image from "next/image";
import styles from "./page.module.css";
import Fab from "@mui/material/Fab";
import { Button, Typography } from "@mui/material";
import ArrowForwardIcon from "@mui/icons-material/ArrowForward";
import Link from "next/link";
//import components

export default async function Page() {
    return (
        <div className={styles.main}>
            <Typography variant="h5" component="h5" className={styles.welcomeTitle}>
                Hello, Welcome to Next Js Mini Project using App Router
            </Typography>
            <Link href="/events">
                <Fab variant="extended">
                    <ArrowForwardIcon sx={{ mr: 1 }} />
                    <Typography variant="h5" component="h5">
                        Check Events
                    </Typography>
                </Fab>
            </Link>
            {/* <Image
                src="/vercel.svg"
                alt="Vercel Logo"
                className={styles.vercelLogo}
                width={100}
                height={24}
                priority
            /> */}
        </div>
    );
}
