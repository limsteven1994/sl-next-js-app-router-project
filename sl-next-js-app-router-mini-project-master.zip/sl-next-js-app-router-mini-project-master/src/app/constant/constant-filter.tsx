const months = [
    { value: 0, month: "All" },
    { value: 1, month: "Jan" },
    { value: 2, month: "Feb" },
    { value: 3, month: "Mar" },
    { value: 4, month: "Apr" },
    { value: 5, month: "May" },
    { value: 6, month: "Jun" },
    { value: 7, month: "Jul" },
    { value: 8, month: "Aug" },
    { value: 9, month: "Sep" },
    { value: 10, month: "Oct" },
    { value: 11, month: "Nov" },
    { value: 12, month: "Dec" },
];

const years = [
    { value: 0, year: "All" },
    { value: 2020, year: 2020 },
    { value: 2021, year: 2021 },
    { value: 2022, year: 2022 },
    { value: 2023, year: 2023 },
];

export {months, years};