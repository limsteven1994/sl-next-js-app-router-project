import * as React from "react";
import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
import DateRangeIcon from "@mui/icons-material/DateRange";
import LocationOnIcon from "@mui/icons-material/LocationOn";
import Typography from "@mui/material/Typography";
import { CardActionArea } from "@mui/material";
import Stack from "@mui/material/Stack";
import Grid from "@mui/material/Grid";
export default function EventCard(props: any) {
    return (
        <Box sx={{ p: 1 }}>
            <Card>
            <CardActionArea>
                <CardMedia
                    component="img"
                    height="150"
                    image={props?.data?.image}
                    alt={props?.data?.image}
                />
                <CardContent>
                    <Typography gutterBottom variant="h5" component="div">
                        {props?.data?.title}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                        {props?.data?.description}
                    </Typography>
                    <Grid container direction="row" alignItems="center" rowSpacing={1} columnSpacing={1}>
                        <Grid item>
                            <DateRangeIcon />
                        </Grid>
                        <Grid item>{props?.data?.date}</Grid>
                    </Grid>
                    <Grid container direction="row" alignItems="center" rowSpacing={1} columnSpacing={1}>
                        <Grid item>
                            <LocationOnIcon />
                        </Grid>
                        <Grid item>{props?.data?.location}</Grid>
                    </Grid>
                </CardContent>
            </CardActionArea>
        </Card>
        </Box>
    );
}
