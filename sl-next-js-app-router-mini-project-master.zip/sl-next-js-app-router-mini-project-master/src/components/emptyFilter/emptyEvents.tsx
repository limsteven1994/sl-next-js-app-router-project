import React from "react";
import Stack from "@mui/material/Stack";
import Alert from "@mui/material/Alert";
import AlertTitle from "@mui/material/AlertTitle";
import { Typography } from "@mui/material";
import WarningAmberIcon from '@mui/icons-material/WarningAmber';
import Grid from "@mui/material/Grid";
const EmptyEvents = () => {
    return (
        <Grid container spacing={2}>
            <Grid item xs>
                <Alert icon={<WarningAmberIcon fontSize="inherit" />} severity="warning">
                    <Typography variant="h5" component="h5">
                    No Events found for selected date
                    </Typography>
                </Alert>
            </Grid>
        </Grid>
    );
};

export default EmptyEvents;
